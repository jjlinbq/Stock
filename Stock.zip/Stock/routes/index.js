var express = require('express');
var router = express.Router();
var http = require('http');
var cheerio = require('cheerio');
var iconv = require('iconv-lite');
var mssql = require('mssql');
function getFullData(next,page,year,Res,stockarray,stockname){
	var url = 'http://money.finance.sina.com.cn/corp/go.php/vMS_MarketHistory/stockid/'+page+'.phtml'+'?year='+year+'&jidu='+next;
	http.get(url,function(res){  //通过get方法获取对应地址中的页面信息
		var chunks = [];
		var size = 0;
		res.on('data',function(chunk){   //监听事件 传输
			chunks.push(chunk);
			size += chunk.length;
		});
		res.on('end',function(){  //数据传输完
			var data = Buffer.concat(chunks,size);  
			var change_data = iconv.decode(data,'gb2312'); 
			var html = change_data.toString();
			//console.log(html);
			var $ = cheerio.load(html); //cheerio模块开始处理 DOM处理
			var stock_list = $("#FundHoldSharesTable tbody tr");
			var stockname = $(".tbtb01 h1").text();
			console.log("stock_list: "+stock_list.length);
			if(stock_list.length!=0){
				stock_list.each(function(){   //对页面岗位栏信息进行处理  每个岗位对应一个 li  ,各标识符到页面进行分析得出
				var texts = $(this).find('td').eq(0).find('div').text();
					if(texts!='日期'){
						var job = {};
						job.date = texts;
						job.openprice = $(this).find('td').eq(1).find('div').text();
						job.highprice = $(this).find('td').eq(2).find('div').text();
						job.closeprice = $(this).find('td').eq(3).find('div').text();
						job.lowprice = $(this).find('td.tdr').eq(0).find('div').text();
						job.num = $(this).find('td.tdr').eq(1).find('div').text();
						job.sum = $(this).find('td.tdr').eq(2).find('div').text();
						stockarray.push(job);  
					}
				});
			}
			console.log(next);
			if(next>1){
				getFullData(--next,page,year,Res,stockarray,stockname);
			}else{
				Res.json({stockArray:stockarray,stockName:stockname});
			}
		});
	});
}
/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: '简单nodejs爬虫' });
  });
 router.get('/api/Users',function(req, res, next){
	 var config = {
		 user:'sa',
		 password:'a.123456',
		 server:'10.4.178.90',
		 database:'XMMetroOA',
		 options:{
			 encrypt:true
		 }
	 };
	 mssql.connect(config).then(function(){
		 new mssql.Request().input('loginid',mssql.Char,'zengjh').query('select * from SEC_User where LoginId=@loginid').then(function(recordset){
			 mssql.close();
			 res.json(recordset);
		 });
	 });
 });
router.get('/getJobs', function(req, res, next) { // 浏览器端发来get请求
	var page = req.param('stocknum');  //获取get请求中的参数 page
	var year = req.param('year');
	console.log("stocknum: "+page);
	var Res = res;  //保存，防止下边的修改
	//url 获取信息的页面部分地址
	var stockarray = [];
	var stockname='';
	getFullData(4,page,year,Res,stockarray,stockname);
});

module.exports = router;